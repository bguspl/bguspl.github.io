package unprotectedCounter;

/**
 * SPL101 PS #01 Threads02.java
 *
 * Two threads attempting to write into a single
 * Printer
 */

public class Threads03
{
	/**
	 * Demonstrating problems with access to a shared resource.
	 */
	public static void main(String[] a) {
		for (int i=0;i<10;i++){
			// create our shared object
			Counter ctr = new Counter();
			// send same unprotected object to two different threads
			Thread t1 = new Thread(new Incrementer(ctr));
			Thread t2 = new Thread(new Incrementer(ctr));
			//start running the two threads
			t1.start();
			t2.start();
			//wait until their job is done

			while (t1.isAlive() || t2.isAlive()); //wait until all done.
			//print out result of attempt i
			System.out.println("Attempt " + i + ", total value: " + ctr.getValue());
		}
	}
}