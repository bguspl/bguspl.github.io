package unprotectedCounter;

public class Counter{
	private int fCounter;

	public Counter(){
		fCounter = 0;
	}
	
	public void increment(){
		fCounter++;
	}
	
	public int getValue(){
		return fCounter;
	}
}