#include "StringQueueStack.h"

StringQueueStack::Link::Link(std::string* data, StringQueueStack::Link* next) : data(data), next(next) {}

void StringQueueStack::push(const std::string* data)
{
    first = new Link{new std::string(*data), first}; // insert a new link before first

    if (!last)
        last = first;
}

void StringQueueStack::append(const std::string* data)
{
    Link* newLink = new Link{new std::string(*data), nullptr};

    if (last)
        last = last->next = newLink; // evaluates "last->next = newLink" and then "last = last->next"
    else
        first = last = newLink;
}

std::string* StringQueueStack::pop()
{
    if (!first) // stack is empty?
        return nullptr;

    if (last == first) // only 1 item in the stack?
        last = nullptr;

    std::string* data = first->data; // save the data so that we can return it later
    Link* oldHead = first; // save the head so that we can free it later
    first = first->next; // set the head to whatever comes next
    delete oldHead;
    return data;
}

void StringQueueStack::clear()
{
    while (first)
        delete pop(); // delete the data
}

StringQueueStack::StringQueueStack(const StringQueueStack& other) : first{nullptr}, last{nullptr}
{
    *this = other; // invoke copy assignment operator to do the work for us
}

StringQueueStack::~StringQueueStack()
{
    clear();
}

StringQueueStack& StringQueueStack::operator=(const StringQueueStack& other)
{
    if (this != &other) { // is this not self assignment?
        clear();
        for (Link* link = other.first; link != nullptr; link = link->next)
            append(link->data); // append will keep the correct order
    }

    return *this;
}
