#pragma once


#include <string>

class StringQueueStack
{
    struct Link
    {
        std::string* data;
        Link* next;
        Link(std::string* data, Link* next);
    } * first, * last;

public:

    StringQueueStack() = default;

    // the rule of 3
    StringQueueStack(const StringQueueStack& other);
    ~StringQueueStack();
    StringQueueStack& operator=(const StringQueueStack& other);

    // other class methods
    void push(const std::string* data);
    void append(const std::string* data);
    std::string* pop();
    void clear();
};
