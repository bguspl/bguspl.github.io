#include "StringQueueStack.h"

#include <iostream>


void pushAndPrint(StringQueueStack *sqs, std::string *s)
{
    std::cout << "Pushing " << *s << std::endl;
    sqs->push(s);
}

void appendAndPrint(StringQueueStack *sqs, std::string *s)
{
    std::cout << "Appending " << *s << std::endl;
    sqs->append(s);
}

void popAndPrint(StringQueueStack* sqs)
{
    std::string *s = sqs->pop();
    std::cout << "Popped: " << *s << std::endl;
    delete s;
}

int main()
{
    StringQueueStack *sqs = new StringQueueStack();

    std::string s1{"1"}, s2{"2"};

    pushAndPrint(sqs, &s1);
    pushAndPrint(sqs, &s2);

    popAndPrint(sqs);
    popAndPrint(sqs);

    appendAndPrint(sqs, &s1);
    appendAndPrint(sqs, &s2);

    popAndPrint(sqs);
    popAndPrint(sqs);

    delete sqs;

    return 0;
}
