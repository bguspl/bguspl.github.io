package unprotectedCounter;

public class Incrementer implements Runnable {
	private Counter fCounter;

    
    public Incrementer(Counter ctr) {
        fCounter = ctr;
    }

    /**
     * Main lifecycle.
     * increment the counter 200 times then dies.
     */
    public void run() {
        for (int i = 0; i<200; i++) {
        		fCounter.increment();
        }
    }
}