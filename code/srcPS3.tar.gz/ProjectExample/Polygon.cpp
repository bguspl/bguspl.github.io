#include "Point.h"
#include "Polygon.h"
#include <iostream>

using std::cout;
using std::endl;
using std::vector;


Polygon::Polygon() {}

Polygon::~Polygon() {
	vector<Point*>::iterator iter = _points.begin();
	cout << "DELETING POLYGON: BEGIN" << endl;
	while (iter != _points.end()) {
		cout << "  deleting point: ";
		cout<<(*iter)->getX()<<" ";
		cout<<(*iter)->getY()<<" ";
		cout << endl;
		delete (*iter);
		iter++;
	}
	cout << "DELETING POLYGON: END" << endl;
}

void Polygon::addPoint(Point* p) {
	Point* newp = new Point; //create a copy of the original pt
	newp->setX(p->getX());
	newp->setY(p->getY());
	_points.push_back(newp);
}

Point* Polygon::getPoint(int index) {
	return _points.at(index);
}

int Polygon::getNumOfPoints() {
	return _points.size();
}
