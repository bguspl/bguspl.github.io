class EvenTask implements Runnable {
	
    Even m_even;
 
    EvenTask(Even even) {
        m_even = even;
    }

	public void run() {
        for (int i = 0; i < 50; i++) {
            System.out.println(m_even.next());
        }
    }
}