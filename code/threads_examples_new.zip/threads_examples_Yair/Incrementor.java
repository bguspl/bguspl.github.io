public class Incrementor implements Runnable {
    private Counter counter;
 
    public Incrementor(Counter ctr) {
        counter = ctr;
    }
 
    public void run() {
        for (int i = 0; i<500; i++) {
                counter.increment();
        }
    }
}