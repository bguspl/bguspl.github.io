class EvenThatThrowsException {
	
    private long n = 0;
 
    /**
     * return an even number.
     * @return an even number not returned before by this object.
     * @throws NotEvenException in case a pre- or post- condition is broken.
     */
    //@ pre-condition: n is even
    public long next() throws Exception {
    	
        if (n%2 != 0) {
            throw new Exception("PRE: n is not even!");
        }
        n++;
        
        try {Thread.sleep(30);} catch (InterruptedException e) {}
        
        n++;
        if (n%2 != 0) {
            throw new Exception("POST: n is not even!");
        }
        return n;
    }
    //@ post-condition : n is greater in two
}