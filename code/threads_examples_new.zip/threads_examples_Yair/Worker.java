public class Worker {
 
    private int id;
    
    public Worker(int id) {
        this.id = id;
    }
    
    public void subscribeToNotifier(TimeNotifier notifier) {
    	
        long threadID = Thread.currentThread().getId();
        
        notifier.subscribeToNotifier(() -> 
            {
                System.out.println("{Worker "+ id +" was notified that three seconds passed. " +
                        "This callback function was defined in Thread: "+threadID +
                        " and activated on Thread: "+Thread.currentThread().getId() +"}");
            });
    }
}