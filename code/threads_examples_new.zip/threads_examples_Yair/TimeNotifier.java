import java.util.LinkedList;
import java.util.List;

public class TimeNotifier implements Runnable
{
    private List<TimePassedEvent> subscribers;
    
    public TimeNotifier ()
    {
        subscribers = new LinkedList<TimePassedEvent>();
    } 
    
    public void subscribeToNotifier(TimePassedEvent ie) {
        subscribers.add(ie);
    }
 
    @Override
    public void run() {
    	
        try {
           Thread.sleep(3000);
        } catch (InterruptedException e1) {}
 
        for (TimePassedEvent e : subscribers) {
                e.callBack();
        }
    } 
}