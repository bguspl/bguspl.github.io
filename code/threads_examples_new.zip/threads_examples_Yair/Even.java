class Even {
	
    private int n = 0;
 
    /**
     * return an even number.
     * @return an even number not returned before by this object.
     */
    //@ pre-condition: n is even
    public int next() {
    	
        n++;
        // sleep(30) will cause synchronization problem to occur more frequently in this example.
        // in a real application (without the sleep) the problem will be rare.
        // thats precisely what makes it dangerous!
        try {Thread.sleep(30);} catch (InterruptedException e) {}
        n++;
        
        return n;
    }
    //@ post-condition : n is greater by two
}