public interface TimePassedEvent
{
    public void callBack();
}