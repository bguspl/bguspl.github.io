import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadsExamples {

	private static void assignTaskToThreads() {
		
		for (int i = 0; i < 2; i++) {
			Runnable r = new SimpleRunnable(i);
			Thread t = new Thread(r);
			t.start();
			
		}
	}
	
	private static void assignTaskToThreadsUsingExecutoe() {
		
		ExecutorService e = Executors.newFixedThreadPool(10);
		
        for (int i = 0; i < 5; i++) {
        	Runnable r = new SimpleRunnable(i);
        	e.execute(r);
        }
        e.shutdown();
	}
	
	private static void severalIncrementors() throws InterruptedException {

		for (int i=0;i<10;i++){
			
            Counter ctr = new Counter();
            
            Thread t1 = new Thread(new Incrementor(ctr));
            Thread t2 = new Thread(new Incrementor(ctr));
            
            t1.start();
            t2.start();
            
            t1.join(); 
            t2.join();   
            
            System.out.println("Attempt " + i + ", total value: " + ctr.getValue());
        }
	}	
	
    public static void invariantViolation() {
    	
    	ExecutorService e = Executors.newFixedThreadPool(10);
        Even ev = new Even();
        for (int i=0; i<10; i++) {
            e.execute(new EvenTask(ev));
        }
        e.shutdown();
    }
    
   public static void nowEvenThrowsException() {
    	
    	ExecutorService e = Executors.newFixedThreadPool(10);
        EvenThatThrowsException ev = new EvenThatThrowsException();
        for (int i=0; i<10; i++) {
            e.execute(new EvenTaskWithException(ev));
        }
        e.shutdown();
    }
   
   public static void simulator() {
	   
	   TimeNotifier notifier = new TimeNotifier();
       
       for (int i=0;i<3;i++) {
           Worker w = new Worker(i);
           w.subscribeToNotifier(notifier);
       }
       
       Thread t = new Thread(notifier);
       t.start();
   }
	
	public static void main(String[] args) throws InterruptedException {
		
		// uncomment the example you want to explore
		
		//assignTaskToThreads();
		//assignTaskToThreadsUsingExecutoe();
		//severalIncrementors();
		//invariantViolation();
		//nowEvenThrowsException();
		//simulator();
}
	
}
