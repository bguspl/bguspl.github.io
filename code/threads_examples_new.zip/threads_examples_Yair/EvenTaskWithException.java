public class EvenTaskWithException implements Runnable {

    EvenThatThrowsException m_even;
    
    EvenTaskWithException(EvenThatThrowsException even) {
        m_even = even;
    }

	public void run() {
        for (int i = 0; i < 50; i++) {
            try {
            	System.out.println(m_even.next());
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
    }
}
