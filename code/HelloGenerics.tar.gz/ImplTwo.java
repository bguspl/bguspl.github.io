public class ImplTwo implements HelloInterface<SampleTwo> {
    @Override
    public void do_something(SampleTwo blob) {
        blob.number_two();
        blob.two_field += 1;
        blob.number_two();
    }
}
