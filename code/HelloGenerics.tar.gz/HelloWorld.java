public class HelloWorld {
    public static void main(String[] args) {
        HelloInterface implone = new ImplOne();
        HelloInterface impltwo = new ImplTwo();

        SampleOne one = new SampleOne();
        SampleTwo two = new SampleTwo();

        implone.do_something(one);
        impltwo.do_something(two);


        implone.do_something(one);
        impltwo.do_something(two);
    }

}
