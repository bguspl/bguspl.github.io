

public class ImplOne implements HelloInterface<SampleOne> {
    @Override
    public void do_something(SampleOne blob) {
        blob.number_one();
        blob.one_field+=1;
        blob.number_one();
    }
}
