public interface HelloInterface<T> {

    void do_something(T blob);
}
