public class SampleTwo {


    public int two_field = 2;
    void number_two()
    {
        System.out.println(two_field);
    }
}
