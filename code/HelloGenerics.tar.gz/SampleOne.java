public class SampleOne {

    public int one_field = 1;
    void number_one()
    {
        System.out.println(one_field);
    }
}
